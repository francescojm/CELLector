## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ---- fig.show='hold', eval=FALSE---------------------------------------------
#  library(devtools)
#  install_github("Francescojm/CELLector")
#  library(CELLector)

## ---- fig.show='hold', eval=FALSE---------------------------------------------
#  arules, dplyr, stringr, data.tree, sunburstR, igraph, collapsibleTree, methods

## ---- fig.show='hold', eval=TRUE, echo=TRUE, message=FALSE, warning=FALSE-----
library(CELLector)

## Somatic mutations and copy number alterations found in primary tumours and cell lines
data(CELLector.PrimTum.BEMs)
data(CELLector.CellLine.BEMs)

## Sets of Cancer Functional Events (CFEs: somatic mutations and copy number alterations) involving
## genes in predefined key cancer pathways
data(CELLector.Pathway_CFEs)

## Objects used for decoding cna CFEs identifiers 
data(CELLector.CFEs.CNAid_mapping)
data(CELLector.CFEs.CNAid_decode)

## ---- fig.show='hold'---------------------------------------------------------
### Change the following two lines to work with a different cancer type
tumours_BEM<-CELLector.PrimTum.BEMs$COREAD
CELLlineData<-CELLector.CellLine.BEMs$COREAD


### unicize the sample identifiers for the tumour data
tumours_BEM<-CELLector.unicizeSamples(tumours_BEM)

## ---- fig.show='hold'---------------------------------------------------------
### building a CELLector searching space focusing on three pathways
### and TP53 mutant patients only
CSS<-CELLector.Build_Search_Space(ctumours = t(tumours_BEM),
                                  verbose = FALSE,
                                  minGlobSupp = 0.03,
                                  cancerType = 'COREAD',
                                  pathwayFocused = c("RAS-RAF-MEK-ERK / JNK signaling",
                                                     "PI3K-AKT-MTOR signaling",
                                                     "WNT signaling"),
                                  pathway_CFEs = CELLector.Pathway_CFEs,
                                  cnaIdMap = CELLector.CFEs.CNAid_mapping,
                                  cnaIdDecode = CELLector.CFEs.CNAid_decode,
                                  cdg = CELLector.HCCancerDrivers,
                                  subCohortDefinition='TP53')

## ---- fig.show='hold'---------------------------------------------------------
### visualising the CELLector searching space as a binary tree
CSS$TreeRoot

### visualising the first attributes of the tree nodes
CSS$navTable[,1:11]

### visualising the sub-cohort of patients whose genome satisfies the rule of the 4th node
str_split(CSS$navTable$positivePoints[4],',')


## ---- fig.show='hold',fig.width=8,fig.height=5--------------------------------
### visualising the CELLector searching space as interactive collapsible binary tree
CELLector.visualiseSearchingSpace(searchSpace = CSS,CLdata = CELLlineData)


## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
### visualising the CELLector searching space as interactive sunburst
CELLector.visualiseSearchingSpace_sunBurst(searchSpace = CSS)

## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
### take all the signatures from the searching space
Signatures <- CELLector.createAllSignatures(CSS$navTable)

### mapping the cell lines on the CELLector searching space
ModelMat<-CELLector.buildModelMatrix(Signatures$ES,CELLlineData,CSS$navTable)


### selecting 10 cell lines
selectedCellLines<-CELLector.makeSelection(modelMat = ModelMat,
                                           n=10,
                                           searchSpace = CSS$navTable)

knitr::kable(selectedCellLines,align = 'l')

## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
### Scoring colorectal cancer cell lines based on the searching space assembled in the previous examples
CSscores<-CELLector.Score(NavTab = CSS$navTable,CELLlineData = CELLlineData)

### Visualising the best 3 cell lines according to the considered searching space and criteria
knitr::kable(CSscores[1:3,],align = 'l')

## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
### Scoring colorectal cancer cell lines based on the searching space assembled in the previous examples
CSscores<-CELLector.Score(NavTab = CSS$navTable,CELLlineData = CELLlineData,alfa = 0.10)

### Visualising the best 3 cell lines according to the considered searching space and criteria
knitr::kable(CSscores[1:3,],align = 'l')

## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
## loading a set of high-confidence cancer driver genes from Iorio et al, Cell 2016
data(CELLector.HCCancerDrivers)

## loading a set of variants observed it at least two patients in COSMIC
data(CELLector.RecfiltVariants)

## Assembling a genomic binary event matrix (BEM) for human derived microsatellite stable diploid colorectal carcinoma cell lines,
## resected from male patients using genomic data from the Cell Model Passports, considering only variants observed in COSMIC in at lest two patients
## in high-confidence cancer driver genes
COREAD_cl_BEM <- CELLector.CELLline_buildBEM(
                  Tissue='Large Intestine',
                  Cancer_Type = 'Colorectal Carcinoma',
                  msi_status_select = 'MSI',
                  ploidy_th = c(2,2),
                  GenesToConsider = CELLector.HCCancerDrivers,
                  VariantsToConsider = CELLector.RecfiltVariants)

## showing first entries of the BEM
head(COREAD_cl_BEM)

## bar diagram with mutation frequencies in the BEM for 20 top frequently mutated genes
barplot(sort(colSums(COREAD_cl_BEM[,3:ncol(COREAD_cl_BEM)]),decreasing=TRUE)[1:20],
        las=2,ylab='n. mutated cell lines')

## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
## Assembling BEM for Colorectal Adenocarcinoma (COAD/READ) primary tumours using data from the TCGA as presented in Iorio et al 2016,
## considering only variants observed in COSMIC in at lest two patients in high-confidence cancer driver genes
COREAD_tum_BEM<-
  CELLector.Tumours_buildBEM(Cancer_Type = 'COAD/READ',GenesToConsider = CELLector.HCCancerDrivers,
                             VariantsToConsider = CELLector.RecfiltVariants)

## showing first 25 entries of the BEM
COREAD_tum_BEM[1:5,1:5]

## showing a bar diagram with mutation frequency of 30 top frequently altered genes
barplot(100*sort(rowSums(COREAD_tum_BEM),
                 decreasing=TRUE)[1:30]/ncol(COREAD_tum_BEM),
                 las=2,ylab='% patients')


## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
### Assembling the searching space and visualising it as interactive sunburst

COREAD_tum_BEM<-CELLector.unicizeSamples(COREAD_tum_BEM)
CSS<-CELLector.Build_Search_Space(ctumours = t(COREAD_tum_BEM),
                                  verbose = FALSE,
                                  minGlobSupp = 0.02,
                                  cancerType = 'COREAD')

CELLector.visualiseSearchingSpace_sunBurst(CSS)

## ---- fig.show='hold',fig.width=6,fig.height=6--------------------------------
### take all the signatures from the searching space
Signatures <- CELLector.createAllSignatures(CSS$navTable)

### mapping the cell lines on the CELLector searching space
ModelMat<-CELLector.buildModelMatrix(Signatures$ES,COREAD_cl_BEM,CSS$navTable)


### selecting 5 representative cell lines
selectedCellLines<-CELLector.makeSelection(modelMat = ModelMat,
                                           n=5,
                                           searchSpace = CSS$navTable)

knitr::kable(selectedCellLines,align = 'l')

